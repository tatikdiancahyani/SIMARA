<footer class="bg-gray-200 text-gray-700 py-4 text-center">
    <div class="container mx-auto px-6">
        <p>&copy; {{ date('Y') }} SIMARA. All rights reserved.</p>
    </div>
</footer>
